# Meus Gastos

Atividade de Programação Mobile — UNASP-SP. Kotlin, Jetpack Compose, MVVM, pacote `br.unasp.meusgastos`. Dados somente em memória, sem banco ou API.

## Abrir no Android Studio (Windows)

1. Extraia o ZIP, ou clone o repositório e selecione a branch `atividade/meus-gastos-mvvm`.
2. Android Studio → Open → selecione a pasta **MeusGastos**, que contém settings.gradle.kts.
3. Use o JDK embutido do Android Studio (17 ou 21). Instale Android SDK Platform 36 quando solicitado. Aguarde o Gradle Sync com internet.
4. Selecione emulador ou celular Android 7.0/API 24 ou superior e clique em Run.
5. Para previews, abra ui/TelaGastos.kt e selecione Split ou Design.

A versão final abre com quatro despesas (R$ 201,70), conforme etapa 6. Remova Cinema para reproduzir os três gastos da imagem (R$ 169,70). Categorias rolam horizontalmente em telas pequenas; a página inteira rola para funcionar com teclado aberto.

## Funcionalidades

Cadastrar descrição, valor com vírgula ou ponto e categoria; filtrar; remover por ID; calcular quantidade e total do filtro. O estado sobrevive à rotação pelo ViewModel, mas os dados somem quando o processo é encerrado. Reiniciar o processo recria a demonstração.

## Organização

- model: Categoria, Gasto, contrato e implementações Memoria/Demo; Kotlin puro.
- viewmodel: estado observável e regras; não depende de Compose UI/Context.
- ui: cinco componentes sem estado com cinco previews; valores entram, eventos saem.
- MainActivity: entrada e aplicação do tema.

Para iniciar vazio, troque `GastoRepositoryDemo()` por `GastoRepositoryMemoria()` no parâmetro padrão de GastosViewModel, sem mudar a UI.

## Testes

Windows: `gradlew.bat testDebugUnitTest assembleDebug`.
Linux/macOS: `./gradlew testDebugUnitTest assembleDebug`.
Os testes cobrem validação, filtro/total, remoção por ID, cópia defensiva e substituição do repositório.

Roteiro manual: cadastrar Café/7,50; filtrar Alimentação; remover Café; tentar descrição vazia, valor abc e zero; rotacionar; testar tela pequena e teclado. Veja ESTRAGOS.md para experimentos isolados.

## Histórico e IA

Commits “etapa 1” a “etapa 8”. As etapas intermediárias são incrementais; use a etapa 8 para executar o app completo. Consulte ARQUITETURA.md, ESTRAGOS.md, DIARIO_IA.md e VALIDACAO.md. O arquivo de componentes do AVA não foi fornecido; os componentes foram implementados com base na referência visual anexada.
