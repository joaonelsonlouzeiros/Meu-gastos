# Validação

O ambiente de criação possui Java, mas não possui Android SDK nem emulador. Compilação Android, testes JUnit e verificação visual no dispositivo ainda precisam ser executados no Android Studio. Não foi gerado APK validado.

Foram feitas verificações estáticas da organização, arquivos Gradle, XML, cinco previews e oito commits. Os testes automatizados estão incluídos para execução com Gradle após instalação do SDK.
