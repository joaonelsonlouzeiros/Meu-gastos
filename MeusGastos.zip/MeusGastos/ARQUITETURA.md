# Arquitetura

1. Uma API exige outra implementação de GastoRepository e mudar o ponto que escolhe a implementação. Com o contrato síncrono atual, a interface e as regras não precisam mudar se o adaptador tiver os dados carregados. Uma API real com carregamento, falha e rede assíncrona exige evoluir o contrato (por exemplo, suspend/Flow) e o estado do ViewModel; não é correto executar rede bloqueante em listar(). Os componentes visuais podem continuar recebendo os mesmos valores e eventos, com indicadores adicionais se necessários.

2. O total vem da lista já filtrada. Se fosse atualizado apenas ao adicionar, cadastrar R$ 10 e R$ 20 e remover o primeiro deixaria R$ 30 na tela, embora só restassem R$ 20.

3. Os parâmetros permitem desenhar o formulário com erro no Preview sem criar ViewModel ou repositório. Também deixam o componente reutilizável em outras telas. Um componente que recebesse VM ainda poderia ter preview com infraestrutura extra; o benefício aqui é dispensar essa infraestrutura.

## Perguntas antes de rodar

- Descrição preenchida e valor vazio: “O valor precisa ser um número”, decidido em GastosViewModel.adicionar().
- Troca para Demo: zero arquivos da UI e nenhuma regra alterada; somente a implementação padrão no parâmetro do ViewModel.
- Demo inicia com quatro gastos e R$ 201,70. Removendo Cinema, três gastos e R$ 169,70, como a imagem.
