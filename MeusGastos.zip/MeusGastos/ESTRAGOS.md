# Cinco estragos — análise e roteiro de reprodução

Os efeitos abaixo são previsões fundamentadas no código. Não foram observados em emulador neste ambiente. Não há mensagens literais de execução para registrar. Faça cada mudança isoladamente e desfaça depois do teste; a entrega contém a versão correta.

| Estrago | Previsão / efeito esperado | Como verificar | Mensagem literal |
|---|---|---|---|
| Instanciar o ViewModel na composição | Uma recomposição pode criar outra instância e reiniciar formulário/lista. O objeto deixa de ter o ciclo de vida gerenciado pelo ViewModelStore. | Substituir `viewModel()` por `GastosViewModel()`, cadastrar e digitar. O momento depende das recomposições. | Não se espera erro de compilação; não executado. |
| Usar lista comum | Mudar a lista não notifica o Compose. Outra mudança observável, como limpar o formulário, pode mascarar o problema e atualizar a tela. | Trocar por mutableListOf, remover um item sem mudar outro estado e depois digitar uma letra. | Não se espera exceção; não executado. |
| Guardar total atualizado só no adicionar | Remover ou filtrar deixa o total antigo. | Adicionar 10 + 20 + 30, remover 20: total errado 60 em vez de 40. | Não se espera exceção; não executado. |
| Depender da classe concreta | Não dá para injetar Demo pelo contrato. A troca exige editar a criação concreta e prejudica testes. | Substituir o parâmetro por um campo concreto e tentar passar Demo pelo construtor. | Depende da alteração realizada; não executado, nenhuma mensagem inventada. |
| Validar na UI | Uma segunda tela pode esquecer a validação e cadastrar descrição vazia. Regras se duplicam. | Retirar a validação do VM e chamar adicionar por outro consumidor com descrição vazia. | Não se espera exceção; não executado. |

Para registrar “o que aconteceu”, execute esses passos no Android Studio e substitua as previsões por suas observações. Não apresente esta análise como execução realizada.
