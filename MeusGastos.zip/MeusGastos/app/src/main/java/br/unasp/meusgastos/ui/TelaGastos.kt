package br.unasp.meusgastos.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import br.unasp.meusgastos.model.*
import br.unasp.meusgastos.viewmodel.GastosViewModel
import java.text.NumberFormat
import java.util.Locale

private val Azul = Color(0xFF123D60)
private val Coral = Color(0xFFFA6B49)
private val Fundo = Color(0xFFF1F6FB)
private val Suave = Color(0xFFE5F0FA)
private val TextoSecundario = Color(0xFF5C7F9D)
private fun moeda(valor: Double) = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("pt-BR")).format(valor)

@Composable
fun MeusGastosTheme(content: @Composable () -> Unit) {
 MaterialTheme(colorScheme = lightColorScheme(primary = Azul, secondary = Coral, background = Fundo, surface = Color.White, onSurface = Azul), content = content)
}

@Composable
fun TelaGastos(vm: GastosViewModel = viewModel(), modifier: Modifier = Modifier) {
 // Uma única lista rola formulário e resultados, inclusive com teclado aberto.
 LazyColumn(modifier.fillMaxSize().background(Fundo), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
  item { Text("Meus Gastos", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Azul) }
  item { FormularioGasto(vm.descricao, vm.valorTexto, vm.categoriaSelecionada, vm.erro, vm::aoDigitarDescricao, vm::aoDigitarValor, vm::aoSelecionarCategoria, vm::adicionar) }
  item { FiltroCategorias(vm.filtro, vm::aoFiltrar) }
  item { ResumoTotal(vm.total, vm.quantidade) }
  if (vm.gastosVisiveis.isEmpty()) item { Text("Nenhum gasto nesta categoria.", color = TextoSecundario, modifier = Modifier.padding(16.dp)) }
  items(vm.gastosVisiveis, key = { it.id }) { gasto -> LinhaGasto(gasto) { vm.remover(gasto.id) } }
 }
}

@Composable
fun FormularioGasto(descricao: String, valorTexto: String, categoria: Categoria, erro: String?, aoDigitarDescricao: (String) -> Unit, aoDigitarValor: (String) -> Unit, aoSelecionarCategoria: (Categoria) -> Unit, aoAdicionar: () -> Unit) {
 Surface(shape = RoundedCornerShape(20.dp), color = Color.White) {
  Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
   TextField(value = descricao, onValueChange = aoDigitarDescricao, placeholder = { Text("Descrição do gasto") }, singleLine = true, modifier = Modifier.fillMaxWidth())
   Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
    TextField(value = valorTexto, onValueChange = aoDigitarValor, placeholder = { Text("0,00") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
    Button(onClick = aoAdicionar, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 16.dp)) { Text("Adicionar") }
   }
   Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    Categoria.entries.forEach { Etiqueta(it.rotulo, it == categoria) { aoSelecionarCategoria(it) } }
   }
   erro?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
  }
 }
}

@Composable
fun FiltroCategorias(selecionada: Categoria?, aoFiltrar: (Categoria?) -> Unit) {
 Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
  Etiqueta("Todas", selecionada == null) { aoFiltrar(null) }
  Categoria.entries.forEach { Etiqueta(it.rotulo, it == selecionada) { aoFiltrar(it) } }
 }
}

@Composable
fun Etiqueta(texto: String, selecionada: Boolean, aoClicar: () -> Unit) {
 FilterChip(selected = selecionada, onClick = aoClicar, label = { Text(texto, fontWeight = if (selecionada) FontWeight.Bold else FontWeight.Normal) }, shape = RoundedCornerShape(50), border = null, colors = FilterChipDefaults.filterChipColors(containerColor = Suave, labelColor = TextoSecundario, selectedContainerColor = Coral, selectedLabelColor = Color.White))
}

@Composable
fun ResumoTotal(total: Double, quantidade: Int) {
 Surface(shape = RoundedCornerShape(16.dp), color = Azul) {
  Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
   Column { Text("Total", color = Color(0xFFA8C5DC)); Text(moeda(total), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
   Text("$quantidade gasto(s)", color = Color(0xFFA8C5DC))
  }
 }
}

@Composable
fun LinhaGasto(gasto: Gasto, aoRemover: () -> Unit) {
 Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
  Row(Modifier.fillMaxWidth().padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
   Column(Modifier.weight(1f)) {
    Text(gasto.descricao, color = Azul, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    Text(gasto.categoria.rotulo, color = TextoSecundario, fontSize = 14.sp)
    Text(moeda(gasto.valor), color = Azul, modifier = Modifier.padding(top = 4.dp))
   }
   TextButton(onClick = aoRemover, colors = ButtonDefaults.textButtonColors(contentColor = Coral)) { Text("remover") }
  }
 }
}


@Preview(showBackground = true)
@Composable
fun ResumoTotalPreview() { MeusGastosTheme { ResumoTotal(201.70, 4) } }

@Preview(showBackground = true)
@Composable
fun LinhaGastoPreview() { MeusGastosTheme { LinhaGasto(Gasto(1, "Almoço no bandejão", 18.50, Categoria.ALIMENTACAO)) {} } }

@Preview(showBackground = true, widthDp = 390)
@Composable
fun FormularioComErroPreview() { MeusGastosTheme { FormularioGasto("Café", "abc", Categoria.ALIMENTACAO, "O valor precisa ser um número", {}, {}, {}, {}) } }

@Preview(showBackground = true, widthDp = 390)
@Composable
fun FiltroCategoriasPreview() { MeusGastosTheme { FiltroCategorias(null) {} } }

@Preview(showBackground = true)
@Composable
fun EtiquetaPreview() { MeusGastosTheme { Etiqueta("Alimentação", true) {} } }
