package br.unasp.meusgastos

import br.unasp.meusgastos.model.*
import br.unasp.meusgastos.viewmodel.GastosViewModel
import org.junit.Assert.*
import org.junit.Test

class GastosTest {
 @Test fun validaEntradasEAdicionaComVirgula() {
  val vm = GastosViewModel(GastoRepositoryMemoria())
  vm.adicionar(); assertEquals("Informe a descrição do gasto", vm.erro)
  vm.aoDigitarDescricao(" Café "); vm.aoDigitarValor("abc"); vm.adicionar()
  assertEquals("O valor precisa ser um número", vm.erro)
  for (valor in listOf("NaN", "Infinity")) { vm.aoDigitarValor(valor); vm.adicionar(); assertNotNull(vm.erro) }
  vm.aoDigitarValor("0"); vm.adicionar(); assertEquals("O valor precisa ser maior que zero", vm.erro)
  vm.aoDigitarValor("7,50"); vm.adicionar()
  assertNull(vm.erro); assertEquals(7.50, vm.total, 0.001)
  assertEquals("Café", vm.gastos.single().descricao); assertEquals("", vm.descricao)
 }
 @Test fun filtroETotalAcompanhamRemocao() {
  val vm = GastosViewModel(GastoRepositoryDemo())
  assertEquals(4, vm.quantidade); assertEquals(201.70, vm.total, 0.001)
  vm.aoFiltrar(Categoria.TRANSPORTE); assertEquals(9.20, vm.total, 0.001)
  vm.remover(2); assertEquals(0, vm.quantidade); assertEquals(0.0, vm.total, 0.001)
  vm.aoFiltrar(null); assertEquals(192.50, vm.total, 0.001)
 }
 @Test fun repositorioRemovePorIdEDevolveCopia() {
  val repo = GastoRepositoryMemoria()
  repo.adicionar("Almoço", 10.0, Categoria.ALIMENTACAO)
  repo.adicionar("Almoço", 20.0, Categoria.ALIMENTACAO)
  val anterior = repo.listar(); repo.remover(anterior.first().id)
  assertEquals(2, anterior.size); assertEquals(20.0, repo.listar().single().valor, 0.001)
 }
 @Test fun contratoAceitaOutraFonteSemMudarRegras() {
  val fonte = object : GastoRepository {
   private var dados = listOf(Gasto(100, "API simulada", 42.0, Categoria.OUTROS))
   override fun listar() = dados
   override fun adicionar(descricao: String, valor: Double, categoria: Categoria) { dados = dados + Gasto(101, descricao, valor, categoria) }
   override fun remover(id: Long) { dados = dados.filterNot { it.id == id } }
  }
  val vm = GastosViewModel(fonte)
  assertEquals(42.0, vm.total, 0.001); vm.remover(100); assertEquals(0, vm.quantidade)
 }
}
